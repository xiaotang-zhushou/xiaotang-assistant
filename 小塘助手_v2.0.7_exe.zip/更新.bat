@echo off
rem ================================================================
rem XiaoTang Assistant - one-click update entry.
rem ASCII only on purpose: Chinese in .bat gets mangled by cmd's codepage.
rem
rem v3 (2026-10-08). Why it is written this way:
rem   * close the running app FIRST. A running app locks its own .exe.
rem     That is exactly why older packs "finished updating" while the
rem     version never changed, and why clicking again changed nothing.
rem   * update, then WATCH the program file: it must really change.
rem   * if it downloaded something but the file did not change, close the
rem     app and try once more (this is what rescues already-stuck packs).
rem   * if nothing was downloaded, there is simply nothing to install -
rem     say so and stop. No scary message for an up-to-date user.
rem   * every step goes to update_log.txt (ASCII). If it ever fails for
rem     real, the user sends us that one file; nothing else to ask.
rem   * if the program file is missing entirely (antivirus ate it), this
rem     file downloads a fresh pack and puts it back by itself.
rem   * this file never deletes itself: an updater that removes the entry
rem     is exactly how customers end up with "the update file is gone".
rem ================================================================
title XiaoTang Assistant - Update
mode con: cols=100 lines=32 >nul 2>nul
setlocal
set "PACK=%~dp0"
set "DL=%PACK%update"
set "LOG=%PACK%update_log.txt"
set "SITE=https://xiaotang-zhushou.pages.dev"
set "EXE="
set "CHANGED=0"
set "GOT=0"
set "NOTHING=0"
set "TRIED=0"
echo Updating XiaoTang Assistant.
echo Please wait and keep this window open - it closes by itself when done.
echo.
call :log "=== update starts ==="
call :kill_app
call :find_exe
call :marks
if exist "%EXE%" goto :try_normal
echo [1/3] updating ...
call :fetch_pack
if not exist "%EXE%" goto :fail
call :marks
call :watch
if "%CHANGED%"=="1" goto :start_new
goto :done_ok

:try_normal
echo [1/3] updating ...
call :run_update
if "%CHANGED%"=="1" goto :start_new
call :status_new
if "%NOTHING%"=="1" goto :done_ok
call :downloaded
if "%GOT%"=="0" goto :done_ok
if "%TRIED%"=="1" goto :fail
set "TRIED=1"
echo [2/3] not done yet - closing the app and trying once more ...
call :log "retry: something was downloaded but the program file did not change"
call :kill_app
call :run_update
if "%CHANGED%"=="1" goto :start_new
goto :fail

:start_new
echo [3/3] done. The new version opens by itself in a moment.
call :log "OK - program file replaced"
timeout /t 3 /nobreak >nul
exit /b 0

:done_ok
echo Nothing to install - you are already on the latest version.
call :log "OK - nothing to install (already the latest)"
timeout /t 3 /nobreak >nul
exit /b 0

:fail
call :log "FAILED - program file was not replaced"
echo.
echo The update could not finish by itself.
echo Please do just this:
echo   1) close every XiaoTang Assistant window
echo   2) run this file again
echo   3) still failing? send this one file to us:  update_log.txt
echo      (it sits next to this file)  -  or download a fresh pack at
echo      %SITE%
pause
exit /b 1

:run_update
start "" /wait "%EXE%" --update
call :watch
exit /b 0

:find_exe
set "EXE="
for %%f in ("%PACK%*.exe") do set "EXE=%%~ff"
exit /b 0

:kill_app
rem A running copy holds its own .exe open, so nothing can be replaced yet.
for %%f in ("%PACK%*.exe") do taskkill /f /im "%%~nxf" >nul 2>nul
timeout /t 2 /nobreak >nul
exit /b 0

:marks
rem Remember what the files looked like before the update run.
set "M_EXE="
for %%f in ("%EXE%") do set "M_EXE=%%~zf-%%~tf"
set "M_DL="
for %%f in ("%DL%\cache\*.zip") do set "M_DL=%%~zf-%%~tf"
set "M_PL="
for %%f in ("%DL%\stage\payload\*") do set "M_PL=%%~zf"
exit /b 0

:watch
rem Wait until the program file really changes (the swap runs after the
rem updater exits, so this cannot be checked just once).
set /a W=0
:watch_loop
timeout /t 3 /nobreak >nul
set "A_EXE="
for %%f in ("%EXE%") do set "A_EXE=%%~zf-%%~tf"
if not "%M_EXE%"=="%A_EXE%" set "CHANGED=1"
if "%CHANGED%"=="1" exit /b 0
set /a W+=1
if %W% lss 40 goto :watch_loop
exit /b 0

:downloaded
rem Did this run actually fetch something? If yes and the file still did not
rem change, something blocked the swap - worth one retry, then tell the user.
set "A_DL="
for %%f in ("%DL%\cache\*.zip") do set "A_DL=%%~zf-%%~tf"
set "A_PL="
for %%f in ("%DL%\stage\payload\*") do set "A_PL=%%~zf"
if not "%A_DL%"=="" if not "%A_DL%"=="%M_DL%" set "GOT=1"
if not "%A_PL%"=="" if not "%A_PL%"=="%M_PL%" set "GOT=1"
exit /b 0

:status_new
rem status.txt is written by the program itself on every check (2.0.7 and up):
rem has_new=0 means the program already knows there is nothing newer.
if not exist "%DL%\status.txt" exit /b 0
findstr /c:"has_new=0" "%DL%\status.txt" >nul 2>nul
if not errorlevel 1 set "NOTHING=1"
exit /b 0

:fetch_pack
echo [2/3] the program file is missing - downloading a fresh copy ...
call :log "program file missing - downloading a fresh pack"
if not exist "%DL%" md "%DL%"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ok=$false; for($i=1;$i -le 3;$i++){ try { $j = Invoke-RestMethod '%SITE%/latest.json'; Invoke-WebRequest -Uri $j.exe_url -OutFile '%DL%\pack.zip' -UseBasicParsing; $ok=$true; break } catch { Start-Sleep -Seconds 3 } } ; if(-not $ok){ exit 1 }"
if not exist "%DL%\pack.zip" exit /b 1
powershell -NoProfile -ExecutionPolicy Bypass -Command "if (Test-Path '%DL%\stage') { Remove-Item -Recurse -Force '%DL%\stage' }; Expand-Archive -Force '%DL%\pack.zip' '%DL%\stage'"
copy /y "%DL%\stage\*.exe" "%PACK%" >nul 2>nul
copy /y "%DL%\stage\*.md" "%PACK%" >nul 2>nul
rem Do NOT copy *.bat here: this file IS the update entry cmd is running right now,
rem and overwriting a batch that cmd is reading makes cmd stop mid-file (2026-10-08,
rem reproduced: the fresh copy landed but the log line and the start never ran).
rem The entry file is version independent, so replacing it gains nothing.
if exist "%DL%\stagessets" xcopy /y /e /i /q "%DL%\stagessets" "%PACK%assets" >nul 2>nul
del /q "%DL%\pack.zip" >nul 2>nul
call :find_exe
if not exist "%EXE%" exit /b 1
set "CHANGED=1"
rem log the result BEFORE starting the app: if cmd hands over to the fresh copy and
rem this batch ends right here, the log must still say it worked.
call :log "OK - fresh copy installed"
start "" "%EXE%"
exit /b 0

:log
echo [%DATE% %TIME%] %~1 >>"%LOG%"
exit /b 0
