@echo off
rem XiaoTang Assistant - one-click update (paid or free trial, as long as your
rem license has not expired). ASCII only on purpose: Chinese text in .bat files
rem gets mangled by cmd's codepage handling.
mode con: cols=100 lines=32
title XiaoTang Assistant - Update
set EXE=
for %%f in ("%~dp0*.exe") do set EXE=%%~ff
if defined EXE (
  start "" /wait "%EXE%" --update
) else (
  echo Cannot find the program (no *.exe in this folder).
  echo Please download a fresh copy from:
  echo   https://xiaotang-zhushou.pages.dev/download/
)
echo.
echo If nothing happened, run this again, or ask the person who sold you this pack.
pause
