@echo off
mode con: cols=120 lines=36
for %%f in ("%~dp0*.exe") do start "" "%%~ff"
