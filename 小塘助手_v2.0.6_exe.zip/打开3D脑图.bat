@echo off
rem Open the 3D brain page only.
rem Exe build: run the exe with --open-brain.  Source build: run start.py with --open-brain.
cd /d "%~dp0"
for %%f in ("%~dp0*.exe") do (
    start "" "%%~ff" --open-brain
    exit /b
)
where py >nul 2>nul
if not errorlevel 1 (
    py -3 start.py --open-brain
    exit /b
)
python start.py --open-brain
pause
